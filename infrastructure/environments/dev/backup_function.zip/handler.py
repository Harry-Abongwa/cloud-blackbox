import json
import os
import boto3
import base64
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource("dynamodb")
TABLE_NAME = os.environ["INCIDENT_TABLE"]
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    params = event.get("queryStringParameters") or {}

    severity = params.get("severity")
    limit = int(params.get("limit", 10))
    from_time = params.get("from")
    next_token = params.get("nextToken")

    if not severity:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "severity parameter required"})
        }

    query_args = {
        "IndexName": "severity-index",
        "KeyConditionExpression": Key("severity").eq(severity),
        "Limit": limit * 3,  # slight overfetch for filtering
        "ScanIndexForward": False
    }

    if next_token:
        decoded = json.loads(base64.b64decode(next_token).decode())
        query_args["ExclusiveStartKey"] = decoded

    response = table.query(**query_args)

    items = response.get("Items", [])

    # SAFE Python-level time filtering
    if from_time:
        items = [i for i in items if i.get("eventTime", "") >= from_time]

    items = items[:limit]

    result = {
        "mode": "severity-index",
        "severity": severity,
        "count": len(items),
        "items": items
    }

    if "LastEvaluatedKey" in response:
        token = base64.b64encode(
            json.dumps(response["LastEvaluatedKey"]).encode()
        ).decode()
        result["nextToken"] = token

    return {
        "statusCode": 200,
        "body": json.dumps(result)
    }
